/* Shared Studio frame and local-only ROM import. Modules provide their own workspaces. */
(function (g) {
  'use strict';
  const K = g.Kit, el = K.el;
  const shell = g.CPS3Studio = { modules: new Map(), rom: null, pack: null, active: null,
    register(spec) { shell.modules.set(spec.id, spec); if (shell.rail) drawRail(); },
    mount(root) {
      shell.root = root; shell.rail = el('nav.module-rail', { hidden: true, 'aria-label': 'Studio modules' }); root.prepend(shell.rail); drawRail();
      return shell;
    },
    async activate(id) {
      const mod = shell.modules.get(id); if (!mod) throw new Error('Unknown Studio module.');
      if (shell.active && shell.active.unmount) shell.active.unmount(); shell.active = mod;
      await mod.mount(shell.root, { rom: shell.rom, pack: shell.pack, store: K.store, actions: K.action, toast: K.toast, settings: K.pref }); drawRail();
    },
    async loadPack() { shell.pack = g.SF3_PACK || await K.store.pack.get('music'); return shell.pack; },
    async importZips(files, progress) {
      progress = progress || K.status; progress('Reading your ROM files. They stay on this computer.');
      const zips = {};
      for (const file of files) zips[file.name] = new Uint8Array(await file.arrayBuffer());
      shell.rom = await Cps3Rom.loadZips(zips); progress('ROM verified. Preparing the sounds.');
      shell.pack = await SF3PackBuild.fromRomSet(shell.rom); await K.store.pack.set('music', shell.pack); g.SF3_PACK = shell.pack;
      progress('Sounds ready.'); return shell.pack;
    },
    welcome(root, ready) {
      const status = el('p.hint', null, 'They never leave this computer.'), input = el('input', { type: 'file', accept: '.zip', multiple: true, hidden: true });
      const button = el('button.btn.primary', { 'data-tip': 'Choose ROM files|Choose sfiii3nr1.zip and sfiii3.zip from this computer.', onclick: () => input.click() }, 'Choose ROM files');
      const panel = el('div.empty.welcome', null, el('b', null, 'Bring your ROM.'), el('p', null, 'Drop sfiii3nr1.zip and sfiii3.zip here.'), status, button, input);
      const waiting = new Map();
      async function take(files) {
        for (const f of files) waiting.set(f.name, f); button.disabled = true;
        try { const pack = await shell.importZips([...waiting.values()], text => { status.textContent = text; }); panel.remove(); await ready(pack); }
        catch (e) { status.textContent = e.message; } finally { button.disabled = false; }
      }
      input.onchange = () => take(input.files); panel.ondragover = e => e.preventDefault(); panel.ondrop = e => { e.preventDefault(); e.stopPropagation(); take(e.dataTransfer.files); };
      root.replaceChildren(panel); return panel;
    },
    settings() {
      const body = el('div.vbox', null,
        el('h3', null, 'Audio'), el('p', null, 'Fightcade monitors in mono. Stereo lets you hear the arcade board’s left and right placement.'),
        el('h3', null, 'ROM'), el('p', null, shell.pack ? 'Street Fighter III 3rd Strike · Japan 990512 NO CD (rev 1). Sounds are stored only on this computer.' : 'Load your two ROM files to hear the game’s instruments.'),
        el('h3', null, 'About'), el('p', null, 'CPS3 Studio · Music. Playback runs the original arcade sound driver.'));
      return K.dialog({ title: 'Settings', body });
    }
  };
  function drawRail() { if (!shell.rail) return; shell.rail.hidden = shell.modules.size < 2; shell.rail.replaceChildren(...[...shell.modules.values()].map(m => el('button.btn', { 'data-tip': `${m.title}|Open ${m.title}.`, onclick: () => shell.activate(m.id) }, K.icon(m.icon), m.title))); }
  K.action({ id: 'studio.settings', title: 'Settings', hint: 'See audio, ROM and Studio settings.', icon: 'settings', run: () => shell.settings() });
})(window);
