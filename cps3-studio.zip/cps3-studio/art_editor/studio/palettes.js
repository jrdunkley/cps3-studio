/* Prop-fed Palettes workspace. No ROM, captured data or emulator dependencies. */
(function (g) {
  'use strict';
  const R = g.ArtRamps || (typeof require === 'function' ? require('../js/ramps.js') : null);
  const F = g.ArtPalFmt || (typeof require === 'function' ? require('../js/palfmt.js') : null);
  const clone = o => JSON.parse(JSON.stringify(o));
  const member = (id,p) => id + ':' + p;
  function createModel(groups, notify = () => {}) {
    const ids = new Set(), rows = new Map(), owners = new Map();
    groups.forEach(group => {
      if (!group.id || ids.has(group.id)) throw new Error('Characters and stages need unique ids.'); ids.add(group.id);
      (group.rows || []).forEach(row => {
        if (!row.id || rows.has(row.id) || row.words.length !== 64) throw new Error('Rows need unique ids and exactly 64 words.');
        const orig = Array.from(row.words); orig.forEach(R.valid);
        if (row.readOnly && !row.rule) throw new Error('A read-only row needs its rule.');
        rows.set(row.id,{ ...row, orig, cur:orig.slice() }); owners.set(row.id,group.id);
      });
    });
    let groupId = groups[0] && groups[0].id, selected = new Set(), name = 'Untitled colours', editorGroups = {};
    groups.forEach(group => { editorGroups[group.id] = clone(group.editorGroups || (group.rows || []).flatMap(row => (row.ramps || R.find(row.words)).map(ramp=>({name:ramp.name,members:ramp.pens.map(p=>member(row.id,p))})))); });
    const past = [], future = []; let clip = null, pending = null, importPending = null;
    function ref(m) { const i = m.lastIndexOf(':'), row = rows.get(m.slice(0,i)), pen = Number(m.slice(i+1)); if (!row || !Number.isInteger(pen) || pen < 0 || pen > 63) throw new Error('Unknown palette pen: '+m); return { row, pen }; }
    function snapshot() { return { words:Object.fromEntries([...rows].map(([id,row])=>[id,row.cur.slice()])), editorGroups:clone(editorGroups), name }; }
    function restore(s) { for (const [id,w] of Object.entries(s.words)) rows.get(id).cur = w.slice(); editorGroups = clone(s.editorGroups); name = s.name; pending = null; importPending = null; }
    function effective(original = false, overrides = null) {
      const out = Object.fromEntries([...rows].map(([id,row])=>[id,(original ? row.orig : overrides && overrides[id] || row.cur).slice()]));
      for (const [id,row] of rows) if (row.compute && !original) {
        out[id] = Array.from(row.compute(clone(out))); if (out[id].length !== 64) throw new Error('Computed row needs 64 words.'); out[id].forEach(R.valid);
      } return out;
    }
    function changes() { let n = 0; for (const row of rows.values()) if (!row.readOnly) row.cur.forEach((w,i)=>{ if (w!==row.orig[i]) n++; }); return n; }
    function emit() { notify({ groupId, rows:effective(), changes:changes(), editorGroups:clone(editorGroups), name }); }
    function transaction(fn) { const before = snapshot(); try { fn(); effective(); } catch (e) { restore(before); throw e; } const after = snapshot(); pending = null; importPending = null; if (JSON.stringify(before) !== JSON.stringify(after)) { past.push({before,after}); future.length = 0; emit(); } }
    function editable() { const list = [...selected].map(ref); if (!list.length) throw new Error('Select some pens first.'); if(list.some(x=>x.pen===0))throw new Error('Pen 0 is never drawn.');if (list.some(x=>x.row.readOnly)) throw new Error('This selection includes a computed row. Select editable pens.'); return list; }
    function select(list, mode = 'replace') {
      pending = null; importPending = null; list.forEach(m => { const {row} = ref(m); if (owners.get(row.id) !== groupId) throw new Error('Select pens in the open character or stage.'); });
      if (mode === 'replace') selected = new Set(list); else if(mode === 'remove') list.forEach(m=>selected.delete(m)); else if(mode === 'toggle') list.forEach(m=>selected.has(m)?selected.delete(m):selected.add(m)); else list.forEach(m=>selected.add(m));
    }
    function put(values) { editable(); transaction(()=>{ [...selected].forEach((m,i)=> { const {row,pen}=ref(m); row.cur[pen] = R.word(R.channels(values[i%values.length]),row.cur[pen]); }); }); }
    function normalizedGroups(list) {
      if (!Array.isArray(list)) throw new Error('Groups must be a list.');
      return list.map(gr=> { if (typeof gr.name !== 'string' || !gr.name.trim() || !Array.isArray(gr.members)) throw new Error('Each group needs a name and members.');
        const members = gr.members.map(m=> {
          try { ref(m); return m; } catch (_) {
            const i=m.lastIndexOf(':'), key=m.slice(0,i), pen=Number(m.slice(i+1)), row=[...rows.values()].find(r=>r.legacy && r.legacy.key===key && r.legacy.row===Math.floor(pen/64));
            if (!row) throw new Error('Group member has no matching row: '+m); return member(row.id,pen%64);
          }
        }); members.forEach(m=> { const x=ref(m); if(owners.get(x.row.id)!==groupId) throw new Error('Group belongs to another character or stage.'); }); return { name:gr.name.trim(), members:[...new Set(members)] }; });
    }
    function stageImport(parsed) {
      const pairs = []; const gr = groups.find(x=>x.id===groupId);
      if (parsed.metadata && parsed.metadata.key && parsed.metadata.key !== gr.id && parsed.metadata.key !== gr.legacyKey) throw new Error('This file belongs to '+parsed.metadata.key+'. Open that character or stage first.');
      if (parsed.rows && parsed.rows.length) {
        for (const imported of parsed.rows) {
          let row = rows.get(imported.id);
          if (!row && imported.legacy) row = [...rows.values()].find(r=>owners.get(r.id)===groupId && r.legacy && r.legacy.key===imported.legacy.key && r.legacy.row===imported.legacy.row);
          if (!row && parsed.rows.length===1) row=ref([...selected][0] || member(gr.rows[0].id,0)).row;
          if (!row || owners.get(row.id)!==groupId) throw new Error('No matching palette row for '+imported.name+'.');
          if (row.readOnly) continue;
          pairs.push([row,imported.words.slice()]);
        }
      } else if (parsed.words) {
        const row = ref([...selected][0] || member(gr.rows[0].id,0)).row;
        if (row.readOnly) throw new Error(row.rule);
        if (parsed.words.length!==64) throw new Error('This palette has '+parsed.words.length+' colours; this row needs 64.'); pairs.push([row,parsed.words.slice()]);
      }
      if (new Set(pairs.map(([r])=>r.id)).size!==pairs.length) throw new Error('This import targets the same row twice.');
      pairs.forEach(([,w])=> { if(w.length!==64) throw new Error('Imported row needs 64 colours.'); w.forEach(R.valid); });
      const newGroups = parsed.groups && parsed.groups.length ? normalizedGroups(parsed.groups) : null;
      importPending={ pairs, newGroups, parsed }; pending=null; return clone(parsed.report || []);
    }
    const api = {
      groups, rows, ref, effective, changes, snapshot, restoreDraft(s) {
        if(!s || Object.keys(s.words || {}).length!==rows.size) throw new Error('Draft rows do not match.');
        for (const [id,w] of Object.entries(s.words)) { if(!rows.has(id)||w.length!==64) throw new Error('Draft rows do not match.'); w.forEach(R.valid); if(rows.get(id).readOnly && w.some((v,i)=>v!==rows.get(id).orig[i])) throw new Error('Draft changes a computed row.'); }
        for(const group of groups) { const previous=groupId; groupId=group.id; try { normalizedGroups(s.editorGroups[group.id]); } finally { groupId=previous; } }
        restore(s); emit();
      },
      get groupId() { return groupId; }, get selected() { return [...selected]; }, get name() { return name; }, get editorGroups() { return clone(editorGroups[groupId] || []); }, get pending() { return pending ? effective(false,pending) : null; }, get importPending() { return importPending; }, get canUndo() { return !!past.length; }, get canRedo() { return !!future.length; },
      setGroup(id) { if (!groups.some(x=>x.id===id)) throw new Error('Unknown character or stage.'); groupId=id; selected.clear(); pending=null; importPending=null; },
      setName(value) { transaction(()=> { name=String(value); }); }, select,
      setRGB(rgb) { const w=R.word(rgb); put([w]); },
      setChannel(channel,value) { if(!Number.isInteger(value)||value<0||value>31) throw new Error('Use a whole step from 0 to 31.'); editable(); transaction(()=>[...selected].forEach(m=> { const {row,pen}=ref(m), rgb=R.channels(row.cur[pen]); rgb[channel]=value; row.cur[pen]=R.word(rgb,row.cur[pen]); })); },
      setHSV(h,s,v) { put([R.fromHSV(h,s,v)]); },
      setWord(w) { R.valid(w); put([w]); },
      reset(all = false) { const list = all ? [...rows.values()].filter(r=>owners.get(r.id)===groupId && !r.readOnly).flatMap(r=>Array.from({length:64},(_,p)=>member(r.id,p))) : api.selected; if(!all) editable(); transaction(()=>list.forEach(m=> { const {row,pen}=ref(m); row.cur[pen]=row.orig[pen]; })); },
      resetRow(id) { const row=rows.get(id); if(!row || row.readOnly) throw new Error(row ? row.rule : 'Unknown row.'); transaction(()=>row.cur=row.orig.slice()); },
      copy(rowMode = false) { editable(); if(rowMode) { const row=ref([...selected][0]).row; clip={ row:true, words:row.cur.slice() }; } else clip={ row:false, words:[...selected].map(m=>{const {row,pen}=ref(m);return row.cur[pen];}) }; return clone(clip); },
      paste(rowMode = false) { if(!clip) throw new Error('Copy colours first.'); if(rowMode) { const row=editable()[0].row; if(!clip.row) throw new Error('Copy a row first.'); transaction(()=>row.cur=clip.words.map((w,i)=>R.word(R.channels(w),row.cur[i]))); } else put(clip.words); },
      swap() { const list=editable(); if(list.length!==2) throw new Error('Select exactly two colours to swap.'); const a=list[0],b=list[1], w=a.row.cur[a.pen]; transaction(()=>{a.row.cur[a.pen]=R.word(R.channels(b.row.cur[b.pen]),w);b.row.cur[b.pen]=R.word(R.channels(w),b.row.cur[b.pen]);}); },
      previewShift(delta) { editable(); pending = Object.fromEntries([...rows].map(([id,row])=>[id,row.cur.slice()])); for(const m of selected) { const {row,pen}=ref(m); pending[row.id]=Array.from(R.shift(pending[row.id],[pen],delta)); } return clone(pending); },
      previewGradient() { const list=editable(); if(new Set(list.map(x=>x.row.id)).size!==1) throw new Error('Choose gradient pens in one row.'); const pens=list.map(x=>x.pen).sort((a,b)=>a-b), row=list[0].row; pending=effective(); pending[row.id]=Array.from(R.gradient(row.cur,pens)); return clone(pending); },
      applyPreview() { if(!pending) throw new Error('Preview a shift or gradient first.'); const draft=pending; editable(); transaction(()=>{for(const [id,w] of Object.entries(draft)) if(!rows.get(id).readOnly) rows.get(id).cur=w.slice();}); },
      cancelPreview() { pending=null; importPending=null; },
      addGroup(n) { if(!selected.size) throw new Error('Select colours to group.'); transaction(()=>editorGroups[groupId].push({name:n || 'New ramp',members:api.selected})); },
      editGroup(index,action,value) { transaction(()=>{ const list=editorGroups[groupId], gr=list[index]; if(!gr) throw new Error('Choose a ramp first.'); if(action==='rename') gr.name=String(value).trim() || gr.name; if(action==='add') gr.members=[...new Set([...gr.members,...api.selected])]; if(action==='remove') gr.members=gr.members.filter(m=>!selected.has(m)); if(action==='delete') list.splice(index,1); if(action==='up' && index>0) list.splice(index-1,0,list.splice(index,1)[0]); if(action==='down' && index<list.length-1) list.splice(index+1,0,list.splice(index,1)[0]); }); },
      selectMatching() { const originals=new Set(api.selected.map(m=>{const {row,pen}=ref(m);return row.orig[pen]&32767;})); select([...rows.values()].filter(r=>owners.get(r.id)===groupId&&!r.readOnly).flatMap(r=>r.orig.flatMap((w,p)=>p>0&&originals.has(w&32767)?[member(r.id,p)]:[]))); },
      stageImport,
      applyImport() { if(!importPending) throw new Error('Open a palette file first.'); const plan=importPending; transaction(()=>{plan.pairs.forEach(([r,w])=>r.cur=w.map((value,i)=>plan.parsed.flagSource==='file'?value:R.word(R.channels(value),r.cur[i])));if(plan.newGroups)editorGroups[groupId]=plan.newGroups;if(plan.parsed.metadata && plan.parsed.metadata.name)name=plan.parsed.metadata.name;}); },
      exportData() { return { rows:groups.find(x=>x.id===groupId).rows.map(r=>({id:r.id,name:r.name,words:effective()[r.id],readOnly:!!r.readOnly,rule:r.rule||'',legacy:r.legacy})), groups:api.editorGroups }; },
      undo() { if(!past.length) return false; const step=past.pop(); restore(step.before);future.push(step);emit();return true; },
      redo() { if(!future.length) return false;const step=future.pop();restore(step.after);past.push(step);emit();return true; }
    }; return api;
  }
  function mount(root, props) {
    if(!props || typeof props.toRGB!=='function') throw new Error('Palettes needs the host’s arcade colour conversion.');
    const K=g.Kit, el=K.el, disposers=[], actionIds=[]; let destroyed=false, ready=false, view=0, zoom=1, compare=false, flash=false, flashOn=false, previewInfo=null, groupIndex=0, activeRow=null, format='json', draftMessage='';
    function say(text) { (props.status || K.status)(text); }
    function safe(fn) { return (...args)=> { try { const result=fn(...args); if(result && result.catch) result.catch(e=>say(e.message)); return result; } catch(e) { say(e.message); } }; }
    const draftKey='art-palettes:'+ (props.storageKey || 'workspace'), fingerprint=JSON.stringify(props.groups.map(gr=>[gr.id,gr.rows.map(r=>[r.id,Array.from(r.words)])]));
    const model=createModel(props.groups,change=> { if(props.onChange)props.onChange(change); if(ready){saveDraft(); if(!destroyed)render();} });
    function saveDraft() { try { if(props.persist!==false) localStorage.setItem(draftKey,JSON.stringify({fingerprint,state:model.snapshot(),groupId:model.groupId,view,zoom})); draftMessage='Draft kept on this computer'; } catch(_) { draftMessage='Browser storage unavailable; export JSON to keep your work'; } }
    if(props.persist!==false) { try { const saved=JSON.parse(localStorage.getItem(draftKey)); if(saved && saved.fingerprint===fingerprint) { model.restoreDraft(saved.state); model.setGroup(saved.groupId); view=saved.view||0;zoom=saved.zoom||1;draftMessage='Draft restored'; } } catch(_) { draftMessage='Draft could not be restored; export JSON to keep your work'; } }
    function button(title,hint,fn,cls='btn') { return el('button',{class:cls,type:'button','data-tip':title+'|'+hint,onclick:safe(fn)},title); }
    function bind(title,hint,fn,keys,enabled) { const id='art.palettes.'+ title.toLowerCase().replace(/[^a-z0-9]+/g,'.'); K.action({id,title,hint,keys,group:'Palettes',run:safe(fn),enabled:()=>root.isConnected && (!enabled||enabled())}); actionIds.push(id); const b=button(title,hint,()=>{}); b.onclick=null;K.bind(b,id);disposers.push(()=>K.unbind(b));return b; }
    const left=el('aside.pal-browser'), center=el('section.pal-center'), right=el('aside.pal-editor');
    const search=el('input.field',{placeholder:'Find a character or stage','aria-label':'Find a character or stage','data-tip':'Find|Filter the characters and stages.',oninput:()=>renderBrowser()});
    const nav=el('div.pal-nav'); left.append(el('div.group',null,el('h3',null,'Palettes'),search),nav,el('div.pal-note',null,'All 64 pens · native colour steps'));
    const title=el('h2.grow'), count=el('span.tag.num'), rowsHost=el('div.pal-rows',{'data-tip':'Palette rows|Click a pen; Shift adds. Drag a box; Alt removes.'});
    const undo=bind('Undo','Undo the last colour or ramp edit.',()=>props.onUndo?props.onUndo():model.undo(),'Ctrl Z',()=>props.onUndo||model.canUndo),redo=bind('Redo','Restore the last undone edit.',()=>props.onRedo?props.onRedo():model.redo(),'Ctrl Shift Z, Ctrl Y',()=>props.onRedo||model.canRedo);
    const toolbar=el('header.pal-heading',null,title,count,undo,redo);
    const variant=el('input.field.bare.grow',{value:model.name,'aria-label':'Variant name','data-tip':'Variant name|Name these colours for export.',onchange:safe(e=>model.setName(e.target.value))});
    const onlyUsed=button('All rows','Show only rows used in the current preview.',()=> { showUnused=!showUnused;onlyUsed.textContent=showUnused?'All rows':'Used rows';renderRows(); });let showUnused=true;
    const rowDescription=el('span.dim.grow');center.append(toolbar,el('div.pal-subhead',null,rowDescription,onlyUsed),rowsHost);
    const canvas=el('canvas.pal-preview',{width:384,height:224,'data-tip':'Live preview|Click or box-select colours in the picture. Hold O to compare.'}), previewWrap=el('div.pal-preview-wrap',null,canvas), box=el('div.pal-box',{hidden:true});previewWrap.append(box);
    const hold=button('Original','Hold this button or O to compare with the original.',()=>{});
    hold.onpointerdown=e=> { try{hold.setPointerCapture(e.pointerId);}catch(_){} compare=true;render(); }; hold.onpointerup=hold.onpointercancel=()=> {compare=false;render();};
    const flashButton=button('Flash selection','Blink pixels that use the selected pens.',()=> {flash=!flash;flashButton.classList.toggle('on',flash);drawPreview();});
    const viewButton=button('View','Choose another pose or stage view.',()=> {const views=props.groups.find(gr=>gr.id===model.groupId).views || ['Preview']; K.menu(viewButton,views.map((v,i)=>({label:typeof v==='string'?v:v.name,checked:i===view,run:()=>{view=i;saveDraft();drawPreview();}})));});
    const zoomButton=button('100%','Zoom the preview from 100 to 400 per cent.',()=>{zoom=zoom===4?1:zoom+1;saveDraft();drawPreview();});
    const all=bind('All in view','Select all editable pens shown in the preview.',()=>selectView(false),'Ctrl A'), invert=button('Invert','Select the unselected pens in this view.',()=>selectView(true)), edited=button('Edited','Select every changed pen in this character or stage.',()=> {const gr=props.groups.find(x=>x.id===model.groupId);model.select(gr.rows.filter(r=>!r.readOnly).flatMap(r=>model.rows.get(r.id).cur.flatMap((w,p)=>w!==model.rows.get(r.id).orig[p]?[member(r.id,p)]:[])));render();});
    center.append(el('div.pal-preview-head',null,el('h3.grow',null,'Live preview'),viewButton,zoomButton,hold,flashButton),previewWrap,el('div.pal-foot',null,all,invert,edited,el('span.grow'),el('span.faint',null,props.conversionLabel || 'Arcade colour · supplied by host')));
    const selectionLabel=el('h3'), selectionFacts=el('span.faint.num'), current=el('canvas',{width:136,height:36}), original=el('canvas',{width:136,height:36});
    const samples=el('div.pal-samples',null,el('div',null,current,el('small.faint',null,'Edited')),el('div',null,original,el('small.faint',null,'Original')));
    const controls={}, inputControllers={};
    function number(label,min,max,onCommit,initial=0) { const input=el('input.field.num',{'data-tip':label+'|Type a value or drag the number.', 'aria-label':label}); const control=K.number(input,{min,max,step:1,value:initial,onCommit:safe(onCommit)}); controls[label]=input;inputControllers[label]=control;return input; }
    const rgb=el('div.pal-colour-fields'), hsv=el('div.pal-colour-fields');
    ['R','G','B'].forEach((ch,i)=>rgb.append(el('label',null,el('span.faint',null,ch),number(ch,0,31,v=>{model.setChannel(i,v);render();}))));
    ['Hue','Saturation','Value'].forEach((ch,i)=>hsv.append(el('label',null,el('span.faint',null,ch),number(ch,0,i===0?359:31,v=>{const first=model.ref(model.selected[0]), values=R.hsv(first.row.cur[first.pen]);values[i]=i===0?v:v/31;model.setHSV(...values);render();}))));
    const native=number('Stored value',0,65535,w=>{model.setWord(w);render();});
    const selectionCommands=el('div.pal-command-grid',null,bind('Copy pens','Copy selected colours in selection order.',()=>model.copy(),'Ctrl C'),bind('Paste pens','Paste copied colours, preserving the game’s flag bits.',()=>model.paste(),'Ctrl V'),button('Same original','Select pens that shared this original colour.',()=>{model.selectMatching();render();}),button('Reset pens','Restore selected colours to their original values.',()=>model.reset()),button('Swap colours','Exchange two selected colours.',()=>model.swap()),button('Clear','Clear the selection.',()=>{model.select([]);render();}));
    right.append(el('div.group',null,el('div.hbox',null,selectionLabel,el('span.grow'),selectionFacts),samples,rgb,hsv,el('div.hbox',null,el('span.faint.grow',null,'Stored value'),native),el('p.faint.pal-help',null,'R G B and saturation/value: 0–31. Hue snaps to stored colour steps. The game’s flag stays intact.'),selectionCommands));
    const shiftValues={hue:0,saturation:0,light:0},shiftControls={};
    const shiftFields=el('div.pal-colour-fields'); ['Hue shift','Saturation shift','Light shift'].forEach((label,i)=> {const k=['hue','saturation','light'][i];const field=number(label,i===0?-180:-100,i===0?180:100,v=> {shiftValues[k]=v;model.previewShift(shiftValues);render();});shiftControls[k]=inputControllers[label];shiftFields.append(el('label',null,el('span.faint',null,['Hue','Saturation','Light'][i]),field));});
    const beforeAfter=el('canvas.pal-shift-strip',{width:304,height:44,'data-tip':'Ramp preview|Top is before, bottom is after; every result is a stored colour.'}), pendingLabel=el('p.faint');
    const apply=button('Apply','Apply the preview as one undo step.',()=>model.applyPreview(),'btn primary'), cancel=button('Cancel','Discard the preview.',()=>{model.cancelPreview();render();}), gradient=button('Gradient','Preview a gradient through selected pens, between its two ends.',()=>{model.previewGradient();render();});
    right.append(el('div.group',null,el('h3',null,'Shift ramp'),shiftFields,beforeAfter,pendingLabel,el('div.hbox',null,gradient,el('span.grow'),cancel,apply)));
    const groupName=el('input.field.grow',{'aria-label':'Ramp name',placeholder:'New ramp name','data-tip':'Ramp name|Name a material, such as cloth or skin.'}),groupList=el('div.pal-group-list');
    const newGroup=bind('New group','Make a named group from selected pens.',()=>{model.addGroup(groupName.value.trim());groupName.value='';},'Ctrl G');
    const groupsSave=button('Save groups','Save editor groups without palette colours.',()=>K.download('palette_groups.json',JSON.stringify({format:'cps3-palette-groups',version:1,key:model.groupId,groups:model.editorGroups},null,2),'application/json'));
    const groupsLoad=button('Load groups','Load a groups file or groups from a palette export.',async()=> {const file=await K.pickFile('.json');if(!file)return;const parsed=await F.read('json',await file.text()); if(!parsed.groups.length)throw new Error('This file has no editor groups.');model.stageImport({...parsed,rows:[],words:undefined});model.applyImport();});
    right.append(el('div.group',null,el('div.hbox',null,el('h3.grow',null,'Ramps & groups'),groupsSave,groupsLoad),el('div.hbox',null,groupName,newGroup),groupList));
    const copyRow=button('Copy row','Copy all 64 pens of the selected row.',()=>model.copy(true)),pasteRow=button('Paste row','Paste a complete row, preserving each destination flag.',()=>model.paste(true)),resetRow=button('Reset row','Restore the selected row.',()=>model.resetRow(activeRow));
    const formatButton=el('button.field',{'data-tip':'File format|Choose a palette interchange format.'});K.select(formatButton,[{value:'json',label:'JSON · rows & groups'},{value:'act',label:'Adobe ACT'},{value:'jasc',label:'JASC PAL'},{value:'riff',label:'RIFF PAL'},{value:'png',label:F.hasPng()?'PNG strip':'PNG strip · awaits ArtPng',disabled:!F.hasPng()}],{value:format,onPick:v=>format=v});
    const importButton=button('Import…','Open a palette file. Colour changes are shown before applying.',async()=> {const file=await K.pickFile('.act,.pal,.json,.png'); if(file)await importFile(file);});
    const exportButton=button('Export…','Save this row, or all rows and groups as JSON.',async()=> {const data=format==='json'?model.exportData():model.effective()[activeRow];if(!data)throw new Error('Select a row first.'); const bytes=await F.write(format,data,{metadata:{key:model.groupId,name:model.name}});K.download(model.groupId+'_'+model.name.replace(/[^a-z0-9_-]+/gi,'_')+'.'+(format==='jasc'||format==='riff'?'pal':format),bytes);say('Exported colours; native metadata keeps the game’s flag bits.');});
    right.append(el('div.group',null,el('h3',null,'Rows & files'),el('div.hbox',null,el('span.faint',null,'Variant'),variant),el('div.hbox',null,copyRow,pasteRow,resetRow),formatButton,el('div.hbox',null,importButton,exportButton),el('p.faint.pal-help',null,'JSON keeps rows, names and groups. Other formats keep one row, with native metadata for exact return.')));
    root.classList.add('palettes');root.replaceChildren(left,center,right);
    const resetAll=bind('Reset all','Restore every editable row in this character or stage.',()=>model.reset(true)); toolbar.append(resetAll);
    function rgbCSS(w) { const c=props.toRGB(w); if(!c || c.length<3 || c.slice(0,3).some(n=>!Number.isInteger(n)||n<0||n>255))throw new Error('Host colour conversion returned invalid RGB.'); return '#'+c.slice(0,3).map(n=>n.toString(16).padStart(2,'0')).join(''); }
    function renderBrowser() {
      const query=search.value.trim().toLowerCase();nav.replaceChildren();
      ['character','stage'].forEach(kind=> {nav.append(el('h3.pal-section-label',null,kind==='character'?'Characters':'Stages'));const found=props.groups.filter(gr=>(gr.kind||'character')===kind && gr.name.toLowerCase().includes(query));
        if(!found.length)nav.append(el('p.pal-note.faint',null,'No '+(kind==='character'?'characters':'stages')+' found.'));
        found.forEach(gr=> {const n=gr.rows.reduce((sum,r)=>sum+model.rows.get(r.id).cur.filter((w,i)=>!r.readOnly && w!==model.rows.get(r.id).orig[i]).length,0);const b=button(gr.name,'Open '+gr.name+'’s palette rows.',()=>{model.setGroup(gr.id);activeRow=gr.rows[0]?.id;view=0;saveDraft();render();},'btn ghost pal-group'+(model.groupId===gr.id?' on':''));b.append(el('span.grow'),el('span.faint.num',null,n?String(n):String(gr.rows.length)));nav.append(b);});});
    }
    function renderRows() {
      rowsHost.replaceChildren();const gr=props.groups.find(x=>x.id===model.groupId);if(!gr || !gr.rows.length){rowsHost.append(el('div.empty',null,el('b',null,'No palette rows here.'),el('p',null,'Choose another character or stage.')));return;}
      const effective=compare?model.effective(true):model.pending || model.effective();
      gr.rows.forEach(r=> {
        if(!showUnused && previewInfo && previewInfo.members && !previewInfo.members.some(m=>m && m.startsWith(r.id+':')))return;
        const row=model.rows.get(r.id), article=el('div',{class:'pal-row'+(activeRow===r.id?' active':'')+(r.readOnly?' readonly':'')}), header=el('div.pal-row-header');
        const selectRow=button(r.name,r.readOnly?r.rule:'Select the editable pens in this row. Pen 0 is never drawn.',e=>{activeRow=r.id;model.select(Array.from({length:63},(_,p)=>member(r.id,p+1)),e.shiftKey?'add':'replace');render();},'btn ghost');
        const n=row.cur.filter((w,i)=>w!==row.orig[i]).length;header.append(selectRow,el('span.grow'),el('span.tag',null,r.readOnly?(r.compute?'Computed · read-only':'Read-only'):n?n+' changed':'64 pens'));
        if(r.readOnly)header.append(el('span.faint.pal-rule',{'data-tip':'Read-only|'+r.rule},r.ruleLabel||r.rule));
        const grid=el('div.pal-swatches'); for(let p=0;p<64;p++) {
          const m=member(r.id,p), inGroups=model.editorGroups.filter(x=>x.members.includes(m)), b=button(String(p),p===0?'Pen 0 is never drawn.':r.readOnly?r.rule:'Select pen '+p+'. Shift adds to the selection.',()=>{},'btn pal-pen'+(model.selected.includes(m)?' selected':'')+(row.cur[p]!==row.orig[p]?' edited':'')+(inGroups.length?' joined':'')+(p===0?' transparent':''));
          if(p===0)b.dataset.tip='See-through|Pen 0 is never drawn.';
          b.dataset.member=m;b.style.setProperty('--pen',rgbCSS(effective[r.id][p]));b.setAttribute('aria-pressed',String(model.selected.includes(m)));b.setAttribute('aria-label',r.name+', pen '+p+(inGroups.length?', '+inGroups.map(x=>x.name).join(', '):''));
          if(inGroups.length){b.classList.toggle('ramp-start',!inGroups[0].members.includes(member(r.id,p-1)));b.classList.toggle('ramp-end',!inGroups[0].members.includes(member(r.id,p+1)));b.dataset.tip+=' Ramps: '+inGroups.map(x=>x.name).join(', ')+'.';}grid.append(b);
        }
        for(const ramp of model.editorGroups){const pens=ramp.members.filter(m=>m.startsWith(r.id+':')).map(m=>model.ref(m).pen).sort((a,b)=>a-b);let start=0;
          while(start<pens.length){let end=start;while(end+1<pens.length && pens[end+1]===pens[end]+1 && Math.floor(pens[end+1]/16)===Math.floor(pens[start]/16))end++;
            const bracket=el('div.pal-ramp-bracket',{'aria-hidden':'true'});bracket.style.left=(pens[start]%16*100/16)+'%';bracket.style.width=((pens[end]-pens[start]+1)*100/16)+'%';bracket.style.top=(Math.floor(pens[start]/16)*26)+'px';grid.append(bracket);start=end+1;
          }
        }article.append(header,grid);rowsHost.append(article);
      });
    }
    function drawPreview() {
      if(destroyed)return;const gr=props.groups.find(x=>x.id===model.groupId);if(!gr)return;
      const data=compare?model.effective(true):model.pending || model.effective();
      if(props.preview)previewInfo=props.preview(canvas,data,{groupId:model.groupId,rowId:activeRow,view,zoom,original:compare,selected:model.selected,flash:flash && flashOn,time:performance.now()/1000,toRGB:props.toRGB}) || null;
      else {const c=canvas.getContext('2d');c.clearRect(0,0,canvas.width,canvas.height);previewInfo=null;}
      const fit=zoom===1?Math.max(.1,Math.min(1,(previewWrap.clientWidth-24)/canvas.width,(previewWrap.clientHeight-24)/canvas.height)):zoom;
      canvas.style.width=canvas.width*fit+'px';canvas.style.height=canvas.height*fit+'px';zoomButton.textContent=fit<1?'Fit':zoom*100+'%';
      viewButton.textContent=(gr.views||['Preview'])[view]?.name || (gr.views||['Preview'])[view] || 'Preview';
    }
    function selectView(invertMode) { const gr=props.groups.find(x=>x.id===model.groupId), available=new Set(previewInfo && previewInfo.members?previewInfo.members.filter(Boolean):gr.rows.filter(r=>!r.readOnly).flatMap(r=>Array.from({length:64},(_,p)=>member(r.id,p))));model.select([...available].filter(m=>model.ref(m).pen>0&&!model.ref(m).row.readOnly && (!invertMode||!model.selected.includes(m))));render(); }
    function renderGroups() {
      groupList.replaceChildren();const list=model.editorGroups;if(!list.length)groupList.append(el('p.faint',null,'No groups yet. Select pens, then name a ramp.'));
      list.forEach((gr,i)=> { const row=el('div.pal-ramp-row'), b=button(gr.name,'Select this ramp. Shift adds; double-click renames.',e=>{groupIndex=i;model.select(gr.members,e.shiftKey?'add':'replace');render(!!props.inlineRename);},'btn ghost grow'+(i===groupIndex?' on':''));b.ondblclick=safe(async()=>{if(!props.inlineRename){const n=await K.prompt('Rename group',{value:gr.name});if(n)model.editGroup(i,'rename',n);return;}let done=false;const input=el('input.field.grow',{value:gr.name,'aria-label':'Ramp name','data-tip':'Ramp name|Type a material name; Enter keeps it, Escape cancels.'});const finish=keep=>{if(done)return;done=true;if(keep&&input.value.trim()&&input.value.trim()!==gr.name)model.editGroup(i,'rename',input.value);else render();};input.onkeydown=e=>{if(e.key==='Enter'||e.key==='Escape'){e.preventDefault();e.stopPropagation();finish(e.key==='Enter');}};input.onblur=()=>finish(true);b.replaceWith(input);input.focus();input.select();});
        row.append(b,el('span.num.faint',null,String(gr.members.length)),button('+','Add selected pens to this ramp.',()=>model.editGroup(i,'add')),button('−','Remove selected pens from this ramp.',()=>model.editGroup(i,'remove')),button('↑','Move this ramp up.',()=>model.editGroup(i,'up')),button('↓','Move this ramp down.',()=>model.editGroup(i,'down')),button('×','Delete this editor group; keep its colours.',()=>model.editGroup(i,'delete')));groupList.append(row);});
    }
    function sample(cv,w) {const c=cv.getContext('2d');c.clearRect(0,0,cv.width,cv.height);if(w!==undefined){c.fillStyle=rgbCSS(w);c.fillRect(0,0,cv.width,cv.height);}}
    function render(preserveGroups=false) {
      if(destroyed || !root.isConnected)return;if(model.selected[0])activeRow=model.ref(model.selected[0]).row.id;renderBrowser();const gr=props.groups.find(x=>x.id===model.groupId);title.textContent=gr?gr.name:'Palettes';count.textContent=model.changes()+' changes';variant.value=model.name;rowDescription.textContent=gr?.kind==='stage'?'Palette rows by layer · computed colours stay read-only':'Selectable colours · shared effects and flashes';renderRows();if(!preserveGroups)renderGroups();else [...groupList.querySelectorAll('.pal-ramp-row > button:first-child')].forEach((b,i)=>b.classList.toggle('on',i===groupIndex));drawPreview();
      const sel=model.selected,first=sel[0]?model.ref(sel[0]):null, transparent=sel.some(m=>model.ref(m).pen===0),ro=transparent||sel.some(m=>model.ref(m).row.readOnly);if(first)activeRow=first.row.id;
      selectionLabel.textContent=sel.length?sel.length===1?'Colour editor':'Selection':'Colour editor';selectionFacts.textContent=sel.length?sel.length+(sel.length===1?' pen':' pens'):'Pick a pen';
      const w=first?model.effective()[first.row.id][first.pen]:undefined;sample(current,w);sample(original,first?first.row.orig[first.pen]:undefined);
      if(first){const c=R.channels(w),h=R.hsv(w);['R','G','B'].forEach((ch,i)=>inputControllers[ch].set(c[i],true));['Hue','Saturation','Value'].forEach((ch,i)=>inputControllers[ch].set(Math.round(i===0?h[i]:h[i]*31),true));inputControllers['Stored value'].set(w,true);}
      for(const key of ['R','G','B','Hue','Saturation','Value','Stored value','Hue shift','Saturation shift','Light shift'])controls[key].disabled=!sel.length||ro;
      selectionCommands.querySelectorAll('button').forEach(b=>b.setAttribute('aria-disabled',String(!sel.length||ro)));
      selectionCommands.querySelectorAll('button').forEach(b=>b.disabled=!sel.length||ro);
      const has=!!model.pending;apply.disabled=!has;cancel.disabled=!has;gradient.disabled=sel.length<2||ro;
      pendingLabel.textContent=has?'Preview · before above, after below.':transparent?'Pen 0 is never drawn.':ro?(first.row.rule || 'Computed row · read-only'):'Select a ramp or several pens to preview a shift.';
      const c=beforeAfter.getContext('2d');c.clearRect(0,0,304,44);sel.forEach((m,i)=>{const {row,pen}=model.ref(m), width=304/Math.max(sel.length,1);c.fillStyle=rgbCSS(row.cur[pen]);c.fillRect(Math.floor(i*width),0,Math.ceil(width),20);c.fillStyle=rgbCSS(has?model.pending[row.id][pen]:row.cur[pen]);c.fillRect(Math.floor(i*width),24,Math.ceil(width),20);});
      [copyRow,pasteRow,resetRow].forEach(b=>b.disabled=!first||ro);undo.setAttribute('aria-disabled',String(!model.canUndo));redo.setAttribute('aria-disabled',String(!model.canRedo));if(props.onSelection)props.onSelection(sel);
    }
    async function importFile(file) {
      const ext=file.name.split('.').pop().toLowerCase(), parsed=await F.read(ext,ext==='json'?await file.text():new Uint8Array(await file.arrayBuffer()),{flags:model.effective()[activeRow],toRGB:props.toRGB});const report=model.stageImport(parsed);
      const body=el('div.vbox',null,el('p',null,report.length?report.length+' colours change to the nearest game steps.':'Colours fit the game exactly.'),el('p.faint',null,parsed.flagSource==='none'?'This file has no game flags. Target flags are kept.':'Native words or target flags are kept.'));
      if(report.length){const table=el('table.pal-report',null,el('thead',null,el('tr',null,...['Pen','Before','After','Difference'].map(x=>el('th',null,x))))),tbody=el('tbody');report.forEach(r=>tbody.append(el('tr',null,...[r.index,r.before.join(' '),r.after.join(' '),r.delta.map(n=>(n>0?'+':'')+n).join(' ')].map(x=>el('td.num',null,String(x))))));table.append(tbody);body.append(table);}
      const result=await K.dialog({title:'Import palette',body,width:600,buttons:[{label:'Cancel',value:false},{label:'Apply colours',value:true,primary:true}]});if(result)model.applyImport();else model.cancelPreview();render();
    }
    /* Box selection of swatches, or the host's optional pixel-to-member map. */
    function wireBox(surface,previewMode) {
      let start=null;
      const down=e=>{if(e.button!==0 || (!previewMode && e.target instanceof Element && e.target.closest('button') && !e.target.closest('[data-member]')))return;start={x:e.clientX,y:e.clientY};try{surface.setPointerCapture(e.pointerId);}catch(_){};};
      const move=e=>{if(!start)return;const rect=previewMode?previewWrap.getBoundingClientRect():rowsHost.getBoundingClientRect();box.hidden=false;(previewMode?previewWrap:rowsHost).append(box);Object.assign(box.style,{left:Math.min(start.x,e.clientX)-rect.left+(previewMode?previewWrap.scrollLeft:rowsHost.scrollLeft)+'px',top:Math.min(start.y,e.clientY)-rect.top+(previewMode?previewWrap.scrollTop:rowsHost.scrollTop)+'px',width:Math.abs(start.x-e.clientX)+'px',height:Math.abs(start.y-e.clientY)+'px'});};
      const up=e=>{if(!start)return;const a=start;start=null;box.hidden=true;let found=[];
        if(previewMode && previewInfo && previewInfo.members){const rect=canvas.getBoundingClientRect(),w=previewInfo.width||canvas.width,h=previewInfo.height||canvas.height;const x0=Math.max(0,Math.floor((Math.min(a.x,e.clientX)-rect.left)/rect.width*w)),x1=Math.min(w-1,Math.floor((Math.max(a.x,e.clientX)-rect.left)/rect.width*w)),y0=Math.max(0,Math.floor((Math.min(a.y,e.clientY)-rect.top)/rect.height*h)),y1=Math.min(h-1,Math.floor((Math.max(a.y,e.clientY)-rect.top)/rect.height*h));for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){const m=previewInfo.members[y*w+x];if(m && !model.ref(m).row.readOnly)found.push(m);}}
        else if(!previewMode){const dragged=Math.abs(a.x-e.clientX)+Math.abs(a.y-e.clientY)>4; if(!dragged){const target=document.elementFromPoint(e.clientX,e.clientY)?.closest('[data-member]');if(target)found=[target.dataset.member];}else rowsHost.querySelectorAll('[data-member]').forEach(b=>{const r=b.getBoundingClientRect();if(r.right>=Math.min(a.x,e.clientX)&&r.left<=Math.max(a.x,e.clientX)&&r.bottom>=Math.min(a.y,e.clientY)&&r.top<=Math.max(a.y,e.clientY))found.push(b.dataset.member);});}
        if(!found.length && previewMode && !previewInfo?.members){say('The host has not supplied picture selection for this preview. Select the swatches.');return;}
        model.select([...new Set(found)],e.altKey?'remove':e.shiftKey?'add':'replace');if(found[0])activeRow=model.ref(found[0]).row.id;render();say(model.selected.length+' pens selected.');};
      const cancel=()=>{start=null;box.hidden=true;},wrappedUp=safe(up);surface.addEventListener('pointerdown',down);surface.addEventListener('pointermove',move);surface.addEventListener('pointerup',wrappedUp);surface.addEventListener('pointercancel',cancel);disposers.push(()=>{surface.removeEventListener('pointerdown',down);surface.removeEventListener('pointermove',move);surface.removeEventListener('pointerup',wrappedUp);surface.removeEventListener('pointercancel',cancel);});
    }
    wireBox(rowsHost,false);wireBox(canvas,true);
    const keydown=e=>{if((e.target instanceof Element && e.target.closest('input,textarea,[contenteditable=true]'))||e.ctrlKey||e.metaKey)return;if(e.key.toLowerCase()==='o'){compare=true;render();}if(e.key==='Escape'){model.select([]);render();}if(e.key==='+'||e.key==='='||e.key==='-'){zoom=Math.max(1,Math.min(4,zoom+(e.key==='-'?-1:1)));drawPreview();saveDraft();}};
    const keyup=e=>{if(e.key.toLowerCase()==='o'){compare=false;render();}},blur=()=>{compare=false;render();};document.addEventListener('keydown',keydown);document.addEventListener('keyup',keyup);g.addEventListener('blur',blur);disposers.push(()=>{document.removeEventListener('keydown',keydown);document.removeEventListener('keyup',keyup);g.removeEventListener('blur',blur);});
    const hover=e=>{const tip=e.target.closest('[data-tip]');if(tip && props.status)props.status(tip.dataset.tip.replace(/\|/g,' · '));};root.addEventListener('pointerover',hover);disposers.push(()=>root.removeEventListener('pointerover',hover));
    const resize=()=>drawPreview();g.addEventListener('resize',resize);disposers.push(()=>g.removeEventListener('resize',resize));
    const timer=setInterval(()=>{if(flash){flashOn=Math.floor(performance.now()/350)%2===0;drawPreview();}else if(props.animate)drawPreview();},props.animate?1000/60:350);disposers.push(()=>clearInterval(timer));
    activeRow=props.groups.find(x=>x.id===model.groupId)?.rows[0]?.id;ready=true;render();say(draftMessage || 'Click a pen or drag a box. Shift adds; Alt removes.');
    return {model, select(list,mode){model.select(list,mode);render();const target=[...rowsHost.querySelectorAll('[data-member]')].find(b=>b.dataset.member===list[0]);if(target)target.closest('.pal-row').scrollIntoView({block:'nearest'});},setGroup(id){model.setGroup(id);activeRow=props.groups.find(x=>x.id===id).rows[0]?.id;view=0;render();saveDraft();},refresh:render,importFile,previewShift(delta){model.previewShift(delta);Object.assign(shiftValues,delta);Object.entries(shiftControls).forEach(([k,c])=>c.set(shiftValues[k],true));render();},getPreviewInfo:()=>previewInfo,destroy(){saveDraft();destroyed=true;disposers.forEach(fn=>fn());actionIds.forEach(id=>K.action.remove(id));root.replaceChildren();root.classList.remove('palettes');}};
  }
  const api={mount,createModel,member};g.ArtPalettes=api;if(typeof module!=='undefined')module.exports=api;
})(typeof window !== 'undefined' ? window : globalThis);
