/* True colours: which stored colours the game draws a sprite in, read from the ROM's own tables.
 *
 * Stage-drawn sprites: every sprite a stage's own animation tables call (one table per physical
 * stage, 06615278) is drawn in that stage's first stored bank, at row 128 plus the cell's row bits
 * (selector 0619DE02 by physical index, descriptor table 061B4754).  Checked against 605 of 605
 * recorded sighted rows of such sprites (finish plan step 5).  Several stages may draw one sprite.
 * Ported from the research project's sprite account (derive.js).  No ROM data is stored here.
 */
(function (g) {
  'use strict';
  const BASE = 0x06000000;
  function stageContexts(program) {
    const v = new DataView(program.buffer, program.byteOffset, program.byteLength);
    const u16 = a => v.getUint16(a - BASE), u32 = a => v.getUint32(a - BASE);
    const tables = Array.from({ length: 23 }, (_, i) => u32(0x06615278 + i * 4)), edges = [...new Set([...tables, 0x064755bc])].sort((a, b) => a - b);
    const physical = new Map(), uses = new Map();
    for (const table of new Set(tables)) {
      const end = edges.find(x => x > table), pointers = []; let at = table, ptr;
      while (at + 4 <= end) { ptr = u32(at); at += 4; if (!ptr) break; if (at - table > 1024 || ptr <= table || ptr >= end) throw new Error('Stage pointer bounds'); pointers.push(ptr); }
      if (ptr || !pointers.length || at > Math.min(...pointers) - 8) throw new Error('Stage pointer terminator');
      const unique = [...new Set(pointers)].sort((a, b) => a - b), refs = new Set();
      for (let j = 0; j < unique.length; j++) {
        const p = unique[j], stop = j + 1 < unique.length ? unique[j + 1] - 8 : end, stride = v.getInt16(p - BASE - 8) * 4;
        if (![4, 8, 16, 24].includes(stride) || (stop - p) % stride) throw new Error('Stage stream domain');
        for (let a = p; a < stop; a += stride) { const code = u16(a); if (code >= 256 && stride >= 8) { const sprite = u16(a + 6); if (!u32(0x06800004 + sprite * 8)) throw new Error('Null stage sprite'); refs.add(sprite); } else if (code < 141 && stride >= 8) continue; else break; }
      }
      physical.set(table, refs);
    }
    for (let s = 0; s < 23; s++) { const index = u16(0x0619d8d0 + s * 6); if (index >= 23) throw new Error('Stage selector'); for (const sprite of physical.get(tables[index])) { if (!uses.has(sprite)) uses.set(sprite, []); uses.get(sprite).push(s); } }
    return uses;
  }
  /* Stored rows a stage-drawn sprite uses: [{stage, row, source}] (source as js/palette.js). */
  function stageSources(program, sprite, contexts) {
    const v = new DataView(program.buffer, program.byteOffset, program.byteLength), out = [];
    const p = v.getUint32(0x800004 + sprite * 8) - BASE; if (p < 0 || p + 12 > program.length) return out;
    const chunks = v.getUint16(p + 4), count = v.getUint16(p + 6), attrs = new Set();
    for (let c = 0; c < count; c++) attrs.add(v.getUint16(p + 12 + chunks * 8 + c * 8 + 2));
    for (const s of contexts.get(sprite) || []) {
      const index = v.getUint16(0x19d8d0 + s * 6), selector = v.getUint16(0x19de02 + index * 2), a = 0x1b4754 + selector * 12;
      const src = v.getUint32(a), dst = v.getUint32(a + 4), size = v.getUint32(a + 8);
      for (const attr of [...attrs].sort((x, y) => x - y)) { const row = 128 + (attr & 511), off = row * 128 - dst; if (attr & 512 && row < 512 && off >= 0 && off + 128 <= size) out.push({ stage: s, row, source: src + off }); }
    }
    return out;
  }
  const api = { stageContexts, stageSources };
  if (typeof module !== 'undefined') module.exports = api; else g.ArtTrueColours = api;
})(typeof window !== 'undefined' ? window : globalThis);
