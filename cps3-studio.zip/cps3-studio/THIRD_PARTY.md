# Third-party material

**No third-party code is included.** Everything in this repository was written for it: the SH-2 interpreter, the
sample-chip model, the zip reader, the SHA-256 fallback, the MIDI reader and writer, the compiler and the pages.
There are no packages to install and no external scripts or fonts are loaded.

**Knowledge used, not copied.** The CPS3 program decryption (`studio_kit/core/cps3rom.js`) implements the
address-mask algorithm and uses the keys of the three Street Fighter III games as documented by the CPS3 drivers
of the MAME and FBNeo emulators. Member names and checksums of the ROM sets follow those projects' ROM lists. The sound driver itself is
not described from any outside source: the Studio runs the game's own driver code, read from your ROM.

**Capcom.** Street Fighter III 3rd Strike, its program, music, instruments and sound samples are Capcom's. None of
them is in this repository. Instrument names, piece names and measurements in the code and documents describe the
game so that you can use your own copy of it; they are not the game's data.
