@echo off
if defined CPS3_STUDIO_BROWSER (
  start "" "%CPS3_STUDIO_BROWSER%" %CPS3_STUDIO_BROWSER_ARGS% "%~dp0Open CPS3 Studio.html"
  exit /b
)
start "" "%~dp0Open CPS3 Studio.html"
