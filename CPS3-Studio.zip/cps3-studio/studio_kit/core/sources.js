/* Public source identities. Compatibility is an operation-specific proof, not a version guess. */
(function(g){
  'use strict';
  const data='605dec69e5895663cdd99f01e3f6bcdb62e10073b475d3b876f1ddd065a0f350',bios='8303455407cef92fde62ab6509515cacd0878e21eaa9c3295aca916614d60b3a';
  const original={id:'original',title:'Original game',short:'Original',store:'rom',pack:'music',program:'35ac2d569893926599b0f68d772e98f412573fb76b305ba3ed910f6136dd2de0',data,bios,about:'Street Fighter III 3rd Strike · Japan 990512 NO CD (rev 1)',hint:'Choose sfiii3nr1.zip and sfiii3.zip, or the folder containing your ROMs.',runtime:[]};
  function infinite(id,version,program){return {id,title:'Infinite '+version,short:'Infinite '+version,store:'rom.'+id,pack:'music.'+id,program,data,bios,about:'Infinite '+version+' · Japan 990512 NO CD (rev 1)',hint:'Choose the folder containing Infinite.exe, or the two ROM zips and the files in modes.',modes:['Super SF3','3rd Strike','3v3'],modeOffsets:[37,85],folder:{marker:'Infinite.exe',inner:'Infinite',zips:'roms',settings:'modes',settingsExt:'.nv'},runtime:['infinite','assists','super-assists']};}
  const list=[original,infinite('infinite','1.033','0d97e70a16b287bd5ffc16c8119d35e0748e59aa02dd3c316762275bee52c10d'),infinite('infinite104','1.04','cd05243fa991ea252d78d0f214393fb8c40a1bce3ebd08d511521ecab18f3f9e')];
  const byId=new Map(list.map(s=>[s.id,s]));
  function get(id){const s=byId.get(id);if(!s)throw new Error('Unknown source: '+id);return JSON.parse(JSON.stringify(s));}
  function identity(s){const def=get(s.id),mode=s.mode==null?null:s.mode;if(def.program!==s.program||s.data&&s.data!==def.data||s.bios&&s.bios!==def.bios)throw new Error('Source fingerprints do not match '+def.title);if(mode!==null&&(!def.modes||!Number.isInteger(mode)||mode<0||mode>=def.modes.length))throw new Error('Invalid source mode');if(s.settings&&!/^[0-9a-f]{64}$/i.test(s.settings))throw new Error('Invalid settings fingerprint');return {id:def.id,mode,program:def.program,data:def.data,bios:def.bios,...(s.settings?{settings:s.settings}:{})};}
  function key(s){const v=identity(s);return [v.id,v.mode==null?'original':v.mode,v.program,v.data,v.bios,v.settings||'factory'].join(':');}
  function equal(a,b){return key(a)===key(b);}
  const api={list,get,identity,key,equal};g.CPS3Sources=api;if(typeof module!=='undefined')module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
