@echo off
start "" "%~dp0everything.html"
