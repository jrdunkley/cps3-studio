/* Six-bit CPS3 DMA. Pair values are semantic bytes, never recursive tokens. */
(function(g) {
  'use strict';
  function decode(source, table, length, maxOutput = length + 63, collectReads = false) {
    if (!(source instanceof Uint8Array) || !(table instanceof Uint8Array) || table.length !== 256 || !Number.isSafeInteger(length) || length <= 0 || !Number.isSafeInteger(maxOutput) || maxOutput < length) throw new Error('Positive upload length and a 256-byte pair table required.');
    const out = new Uint8Array(maxOutput), positions = collectReads ? new Set() : null; let p = 0, n = 0, last = 0, tableReads = 0;
    while (n < length) {
      if (p >= source.length) throw new Error('Compressed upload is truncated.');
      const token = source[p++], pair = !!(token & 128), at = (token & 127) * 2;
      for (let k = 0; k < (pair ? 2 : 1); k++) {
        const v = pair ? table[at + k] : token;
        if (pair) { tableReads++; if (positions) positions.add(at+k); }
        const count = v & 64 ? (v & 63) + 1 : 1, pen = v & 64 ? last & 63 : v;
        if (!(v & 64)) last = v;
        if (n + count > maxOutput) throw new Error('Upload exceeds output capacity including its RLE tail.');
        out.fill(pen, n, n + count); n += count;
        if (n >= length) break;
      }
    }
    return { pixels: out.slice(0, n), sourceConsumed: p, tableReads, ...(positions ? {tablePositions:[...positions].sort((a,b)=>a-b)} : {}) };
  }
  function check(pixels) { if (!(pixels instanceof Uint8Array) || !pixels.length || pixels.some(p => p > 63)) throw new Error('Nonempty six-bit pens (0..63) required.'); }
  /* Exact shortest parse for a fixed table, with no output overshoot. At any
     position the last pen is determined by the already decoded prefix. */
  function encodeFixed(pixels, table, requestedLength = pixels.length) {
    check(pixels); if (!(table instanceof Uint8Array) || table.length !== 256) throw new Error('Pair table must be 256 bytes.');
    const n = pixels.length, runs = new Uint32Array(n), cost = new Uint32Array(n + 1), choice = new Uint8Array(n), advance = new Uint16Array(n);
    if (!Number.isSafeInteger(requestedLength) || requestedLength <= 0 || requestedLength > n || n > requestedLength + 63) throw new Error('Invalid requested upload length / RLE tail.');
    cost.fill(n + 1); cost[n] = 0;
    for (let p = n - 1; p >= 0; p--) runs[p] = 1 + (p + 1 < n && pixels[p] === pixels[p + 1] ? runs[p + 1] : 0);
    const lists = Array.from({ length: 64 }, () => []);
    for (let t = 0; t < 128; t++) { const v = table[t * 2]; if (v & 64) { for (const list of lists) list.push(t); } else if (v < 64) lists[v].push(t); }
    function semantic(v, p, last) {
      if (p >= n) return 0;
      const count = v & 64 ? (v & 63) + 1 : 1, pen = v & 64 ? last : v;
      return pixels[p] === pen && runs[p] >= count ? count : 0;
    }
    for (let p = requestedLength - 1; p >= 0; p--) {
      const last = p ? pixels[p - 1] : 0;
      let best = n + 1, token = pixels[p], step = 0;
      const offer = (t, k) => { if (p + k >= requestedLength && p + k !== n) return; if (cost[p + k] + 1 < best) { best = cost[p + k] + 1; token = t; step = k; } };
      offer(pixels[p],1);
      if (pixels[p] === last) for (let k = 1, end = Math.min(64, runs[p]); k <= end; k++) offer(63 + k, k);
      for (const t of lists[pixels[p]]) {
        const v = table[t * 2], a = semantic(v, p, last); if (!a) continue;
        if (p + a >= requestedLength) offer(128 + t, a);
        else { const b = semantic(table[t * 2 + 1], p + a, v & 64 ? last : v); if (b) offer(128 + t, a + b); }
      }
      cost[p] = best; choice[p] = token; advance[p] = step;
    }
    if (!advance[0]) throw new Error('Intended RLE tail cannot be encoded with this pair table.');
    const source = new Uint8Array(cost[0]); for (let p = 0, o = 0; p < n; p += advance[p]) source[o++] = choice[p];
    return { source, table: table.slice(), decodedLength: n, optimal: true };
  }
  /* Free-table construction is deterministic frequency selection followed by
     the exact fixed-table parser. Table selection itself is not globally optimal. */
  function encode(pixels, requestedLength = pixels.length) {
    check(pixels); const tokens = []; let last = 0;
    for (let p = 0; p < pixels.length;) {
      const pen = pixels[p]; if (pen !== last) { tokens.push(pen); last = pen; p++; }
      else { let k = 1; while (k < 64 && p + k < pixels.length && pixels[p + k] === pen) k++; tokens.push(63 + k); p += k; }
    }
    const frequency = new Map(); for (let i = 0; i + 1 < tokens.length; i++) { const pair = tokens[i] * 256 + tokens[i + 1]; frequency.set(pair, (frequency.get(pair) || 0) + 1); }
    const pairs = [...frequency].sort((a,b) => b[1] - a[1] || a[0] - b[0]).slice(0,128), table = new Uint8Array(256);
    pairs.forEach(([v],i) => { table[2*i] = v >>> 8; table[2*i+1] = v & 255; });
    return { ...encodeFixed(pixels, table, requestedLength), optimal: false, parseOptimal: true };
  }
  const api = { decode, encode, encodeFixed }; g.ArtCodec6 = api; if (typeof module !== 'undefined') module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
