(function(root){'use strict';
 const list=[['move','Move','V','Moves the selected pixels; arrow keys nudge.'],['box','Select box','M','Drag a box around pixels. Hold Shift to add.'],['lasso','Lasso','L','Draw around pixels to select them.'],['wand','Select by colour','W','Selects matching pens; contiguous keeps connected pixels.'],['pencil','Pencil','B','Draws with the primary pen; Alt picks a pen.'],['eraser','Eraser','E','Clears pixels on the active paint layer.'],['fill','Fill','G','Fills matching pens with the primary pen.'],['line','Line','U','Draws a straight line; choose rectangle or ellipse above.'],['shade','Shade','O','Paints one step darker along a ramp; Alt makes it lighter.'],['pick','Pick colour','I','Chooses the pen under the pointer.'],['origin','Origin','P','Moves the point the game places, when proved safe.'],['hand','Hand','H','Pans the canvas; hold Space with any tool.'],['zoom','Zoom','Z','Click to zoom in; Alt-click zooms out.']];
 function mount(a,rail,options){
   for(const [id,title,key,hint] of list)rail.append(a.button('tool.'+id,title,hint,()=>{a.tool=id;render();a.canvas.overlay();},'art-'+id,key));
   const divider=document.createElement('span');divider.className='sep';rail.append(divider);
   for(const [id,title,hint,key,icon] of [['tiles','Tiles','The game stores 16 × 16 blocks. Painting in a hatched block adds one.','T','tiles'],['onion','Onion skin','Shows nearby frames aligned by origin.','Y','onion'],['guides','Guides','Shows the origin, ground, centre axis and original outline.',';','origin']])rail.append(a.button(id,title,hint,()=>{a[id]=!a[id];a.canvas.invalidate();render();},'art-'+icon,key));
   function setting(title,hint,items,value,change){const host=document.createElement('button');options.append(host);const select=Kit.select(host,items.map(([value,label])=>({value,label})),{value,onPick:v=>{change(v);render();}});host.dataset.tip=title+'|'+hint;host.title=title;return select;}
   function render(){const active=list.find(t=>t[0]===a.tool);a.canvas.host.dataset.tip=active[1]+'|'+active[3];a.canvas.host.dataset.keys=active[2]+' · Space-drag · Wheel';for(const b of rail.querySelectorAll('[data-action]'))b.classList.toggle('on',b.dataset.action==='tool.'+a.tool||!!a[b.dataset.action]);options.replaceChildren();const label=document.createElement('b');label.textContent=active[1];options.append(label);
     if(['pencil','eraser','shade','line'].includes(a.tool)){
       const size=document.createElement('input');size.className='field num';size.type='number';size.min=1;size.max=64;size.value=a.size;size.title='Size';size.dataset.tip='Size|The width of the brush in pixels.';size.onchange=()=>{a.size=Math.max(1,Math.min(64,Math.round(+size.value)||1));size.value=a.size;};options.append(size);
       if(a.tool==='pencil')options.append(a.localButton('Pixel-perfect','Removes elbows from single-pixel strokes.',()=>{a.pixelPerfect=!a.pixelPerfect;render();},a.pixelPerfect));
       setting('Symmetry','Mirrors each mark across the canvas.',[['off','Symmetry off'],['x','Left-right'],['y','Up-down']],a.symmetry,v=>{a.symmetry=v;});
     }
     if(a.tool==='line')setting('Shape','Choose an exact pixel shape.',[['line','Line'],['rectangle','Rectangle'],['ellipse','Ellipse']],a.shape,v=>{a.shape=v;});
     if(a.tool==='line'&&a.shape!=='line')options.append(a.localButton('Solid','Fills the inside of the shape.',()=>{a.solid=!a.solid;render();},a.solid));
     if(['fill','wand'].includes(a.tool))options.append(a.localButton('Contiguous','Keeps matching pens connected to the clicked pixel.',()=>{a.contiguous=!a.contiguous;render();},a.contiguous));
     if(['fill','wand','pick'].includes(a.tool))options.append(a.localButton('All layers','Reads the visible paint layers together.',()=>{a.allLayers=!a.allLayers;render();},a.allLayers));
     if(['move','box','lasso','wand'].includes(a.tool)){
       for(const [label,hint,fn] of [['Flip','Mirrors the selection exactly.',()=>a.transform('flip')],['Turn','Rotates the selection by one quarter turn.',()=>a.transform('rotate')],['Invert','Selects every pixel outside the selection.',()=>a.select('invert')],['Scale…','Resamples pixels using nearest sampling.',()=>a.freeTransform('scale')],['Rotate…','Resamples pixels using nearest sampling.',()=>a.freeTransform('rotate')]])options.append(a.localButton(label,hint,fn));
     }
     if(a.tool==='origin'){const reason=document.createElement('span');reason.className='dim';reason.textContent=a.capability('origin').reason;options.append(reason);}
     if(a.tool==='hand'||a.tool==='zoom'){const text=document.createElement('span');text.className='dim';text.textContent='Wheel zooms about the pointer · Space-drag pans';options.append(text);}
     const grow=document.createElement('span');grow.className='grow';options.append(grow);
     options.append(a.button('undo','Undo','Restores the last change exactly.',()=>a.undo(),'undo','Ctrl Z'),a.button('redo','Redo','Puts the change back exactly.',()=>a.redo(),'redo','Ctrl Shift Z'));
   }
   render();return{render};
 }
 root.ArtTools={mount,list};
})(globalThis);
