# Drawing for the game

## Change one frame in five steps

1. Open the Studio's launcher, choose Art, and give the welcome both ROM zips. One import
   serves Music and Art. The browser remembers them when local storage is available.
2. Open Library, choose a character, expand an animation and double-click a frame.
3. Read **Shared sprite** and **Room**, then press `B` for Pencil. Choose a pen and draw
   inside the stored tiles. `Alt` picks a pen, `T` shows tiles and `Ctrl Z` undoes a stroke.
4. Play the animation. Use **Every colour** and **Other side** to check other palettes and
   the mirrored picture. `Y` shows nearby frames aligned by origin.
5. Open Deliver. Save **Work** as a `.cps3art` project, then read **Game Check** before writing
   ROM files. A picture that draws in Edit may still need room or a method not yet offered.

## Bring in a sprite sheet

Choose **Import onto…** in Library or the frame strip, and select the sheet. A sheet exported
by this Studio should travel with its JSON manifest. Import uses its rectangles and origins.
Use an unscaled 1× export for importing; larger exports are for sharing pictures.

In **Slice**, set cell size, margins and gaps, or choose **Find sprites** for transparent
gutters. Drop unwanted frames and inspect every outline. In **Match colours**, review the
colour-to-pen rows and heat map. Indexed pictures already using the chosen palette say
**Pens kept exactly**. Dithering is off until you choose it. Partial transparency needs an
explicit choice; the Studio does not guess it away.

In **Place frames**, join each picture to its target and choose origin, feet or centre
alignment. Nudge while looking at the original underneath. Unmatched pictures remain visible.
Nothing is resized. Overflow is shown: trim only if you choose to; keeping extra tiles does
not make those tiles deliverable. Dropping a single picture into Edit adds a paint layer,
or a reference layer. A reference never enters the game.

## Recolour a character

Open Palettes, choose the character and colour, then select pens in the row or preview.
`Shift` adds to the selection; `Alt` removes. Change RGB in the game's whole five-bit steps,
or preview **Shift ramp** and apply it as one undo step. Hold **Original** to compare.
Use the Colour chooser and **Every colour** to inspect a sprite across its colours.

Palette viewing and editing are separate from ROM delivery. Read the workspace's warning
before changing a row; Deliver currently refuses palette changes it cannot write. Export
palette JSON to keep native words, names and groups. Other formats can lose native metadata
when another application saves them. Gill's later colours are made by the game and are
read-only where the workspace cannot preserve them.

## Look at a stage

Open Library's stage view, choose a stage, then inspect its initial layer atlas and stored
colour sets. Export the layer you need as a private reference. An atlas is not a simulation
of the game's camera or moving scene. The exact capability text for this build follows.

**Change a stage’s colours** · limited

Both stored colour banks of every stage can be changed; Deliver writes them into the ROM files. The game applies its own fades to them as it runs.

Both banks of all 23 stages read back exactly from the written files with every other stored row untouched. In forced stage loads on the native machine the edited colours loaded exactly as predicted on 21 stages and changed the picture exactly on 12 banks; the fixtures for stages 13 and 16 never loaded their banks. Ryu's stage and stage 0 also in Fightcade's emulator. Round variants and lighting the game computes are not checked.

**See a stage’s layers** · limited

Each stage’s layers are read from your ROM as the game first loads them, and can be exported.

All 23 initial stage identities: the picture each stage starts with. Moving parts, lighting changes, other rounds and where the camera looks are not shown. One stored stage picture the game was never seen to load is marked unchecked; the two bonus scenes were only seen black.

**Change stage artwork** · Not verified

Stage tiles can be repainted where they are stored. A repainted tile and a moved tile have each appeared exactly as predicted in the game in a test; it is not offered until every reader and possible stage load of those bytes is accounted for.

## What loads in time

Read the load figures in Edit and Deliver where available. Decoded bytes and load requests
describe work; they do not alone predict when a larger replacement appears. The exact
capability text for this build follows.

**Know that a change loads in time** · limited

A sprite replaced inside its own tiles asks the game for exactly the same loads as the original, so it appears when the original would.

Replacements that keep the sprite’s tiles. For anything larger the Studio shows how much the game must load, without a verdict: when a load finishes also depends on what else the game is drawing.

## Put it in the game

Save Work first. In Deliver, read each change and Game Check. Fix or reset any refused change.
When writing is offered, choose an empty private folder or save the downloaded zip.
**Encodes back exactly** and **Reads back from the patched ROM** are checks on those files.
**Seen in the game** requires an actual game comparison for that particular output.

Follow [ROM_GUIDE.md](ROM_GUIDE.md) to supply the remaining members and test an isolated set.
The Studio never changes your installed game. Larger sprites, new frames and stage edits
remain subject to [the generated limits page](WHAT_ART_CANNOT_DO_YET.md).
