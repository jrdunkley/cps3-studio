# songs/ (yours)

A place for your own song files (`*.sf3song.json`) and projects. The arranger's song list (`style/library.js`) and
`style/metrics.js` read them from here. Git ignores everything in this folder except this file, so nothing you
keep here is published by accident.
