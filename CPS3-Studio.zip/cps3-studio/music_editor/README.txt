Read docs/README.md for CPS3 Studio Music, opening it, privacy, the classic editor and verification.
