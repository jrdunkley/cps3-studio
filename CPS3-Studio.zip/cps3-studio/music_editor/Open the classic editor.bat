@echo off
start "" "%~dp0classic.html"
