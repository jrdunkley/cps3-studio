# Updates

## 2026-10-09

- Added Moves: stored timelines, editable move fields, collision boxes, undo/redo and opponent hit preview.
- Added Game: browser gameplay, frame controls, save slots, comparisons, pixel inspection and Try in game links.
- Added shared projects and combined builds with source checks, saved versions and write-conflict detection.
- Expanded Art discovery, scene usage, cut-content annotations and palette tools, including Gill, stage variants, bonus-car and Poison context.
- Added recognised Infinite 1.033/1.04 sources to Art, Moves and Game, with separate source/mode storage.
- Updated portable packaging, bundled emulator source, asset exclusions and documentation.

These notes compare this package with the 2026-10-05 Music/Art release. Capability and storage limits remain in place; this is not a declaration that every planned editor is complete.
